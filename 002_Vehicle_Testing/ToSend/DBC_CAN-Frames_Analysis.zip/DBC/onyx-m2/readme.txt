1. DBC Source: https://github.com/onyx-m2/onyx-m2-dbc/blob/main/tesla_model3.dbc

Doesnt open directly in the Vector CANDb++ Editor.
To open in CANdb++ Editor, need to remove all the signals with BA_
