1. DBC Samples : https://github.com/thezim/DBCTools/tree/master/Samples

2. DBC Tools : https://github.com/thezim/DBCTools/tree/master
Not used for project analysis. Only refered for motivation

